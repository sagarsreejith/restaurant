<?php if ( ! defined('BASEPATH')) exit('No direct access allowed');

$lang['label_email'] 		            = 'Email';
$lang['label_password'] 		        = 'Password';
$lang['label_confirm_password'] 		= 'Confirm Password';
$lang['button_login1'] 			        = 'Login';


