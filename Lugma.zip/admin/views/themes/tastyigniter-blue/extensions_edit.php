<?php echo get_header(); ?>
<?php
	if (!empty($extension)) {
		echo $extension;
	}
?>
<?php echo get_footer(); ?>