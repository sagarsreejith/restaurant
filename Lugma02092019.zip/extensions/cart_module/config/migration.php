<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Migrations version
|--------------------------------------------------------------------------
|
| This is used to set migration version number that the extension should be on.
| This is the version that schema will be upgraded / downgraded to.
|
*/
$config['migration_version'] = 1;