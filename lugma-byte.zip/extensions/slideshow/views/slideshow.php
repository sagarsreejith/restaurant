<style>
/* .background_images:before {
    content: '';
    position: absolute;
    left: 0;
    z-index: 10;
    width: 100%;
    height: 80px;
    top: 40px;
    background: url(assets/images/down.png) repeat-x;
} */
.background_images:after {
    content: '';
    position: absolute;
    left: 0;
    z-index: 10;
    width: 100%;
    height: 80px;
    bottom:-55px;
    background: url(assets/images/up1.png) repeat-x;
}

</style>
<div class="background_images fadeIn">

<img src="assets/images/baoli.jpg">
<!-- <img src="assets/images/d2.jpg"> -->
</div>

<!-- <section class="page-section-pb our-menuss">
                 <div class="container">
                          
                          <div class="row">
                            <div class="owl-carousel" data-items="5" data-md-items="4" data-sm-items="3" data-xs-items="1" data-space="30" >
                              <div class="item">
                                  Sweet1
                              </div>
                              <div class="item">
                                  Sweet2
                              </div>
                              <div class="item">
                                  Sweet3
                              </div>
                              <div class="item">
                                  Sweet4
                              </div>
                              <div class="item">
                                  Sweet5
                              </div>
                              <div class="item">
                                  Sweet6
                              </div>
                              <div class="item">
                                  Sweet6
                              </div>
                              <div class="item">
                                  Sweet6
                              </div>
                              <div class="item">
                                  Sweet6
                              </div>
                            
                            </div>
                          </div>
                        </div>
                </section>

    -->

