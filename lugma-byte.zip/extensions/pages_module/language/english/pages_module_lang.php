<?php if ( ! defined('BASEPATH')) exit('No direct access allowed');

$lang['_text_title'] 			        = 'Pages';
$lang['text_tab_general'] 		        = 'General';

$lang['label_heading'] 			        = 'Heading';

/* End of file pages_module.php */
/* Location: ./extensions/pages_module/language/english/pages_module_lang.php */