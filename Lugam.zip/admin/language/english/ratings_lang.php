<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['text_title'] 		            = 'Ratings';
$lang['text_heading'] 		            = 'Ratings';
$lang['text_list'] 		                = 'Rating List';
$lang['text_empty'] 		            = 'There are no rating, please add.';

$lang['column_name'] 		            = 'Name';

$lang['label_name'] 		            = 'Name';

/* End of file ratings_lang.php */
/* Location: ./admin/language/english/ratings_lang.php */